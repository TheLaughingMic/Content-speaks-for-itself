import time
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait

def link_grabber(url, driver):
    driver.get(url)
    scroll = True
    time.sleep(3)
    for i in range(1, 5):
        scroll_height = 200
        document_height_before = driver.execute_script("return document.documentElement.scrollHeight")
        driver.execute_script(f"window.scrollTo(0, {document_height_before + scroll_height});")
        time.sleep(0.5)


    # target all the link elements on the page
    anchors = driver.find_elements_by_tag_name('a')
    anchors = [a.get_attribute('href') for a in anchors]
    # narrow down all links to shorts links only
    anchors = [a for a in anchors if str(a).startswith("https://www.youtube.com/shorts/")]

    filtered_anchors = []
    for anchor in anchors:
        if anchor not in filtered_anchors:
            filtered_anchors.append(anchor)
    print('Found ' + str(len(filtered_anchors)) + ' links to laughing mic videos')
    return filtered_anchors

# def login(email, passw, alt_email, driver):
#     login_meter = False
#     alert = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.XPATH,
#                                     '/html/body/ytd-app/div/div/ytd-masthead/div[3]/div[3]/div[2]/ytd-button-renderer/a/tp-yt-paper-button'))).click()
#     time.sleep(2)
#     username = WebDriverWait(driver, 40).until(
#         EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='identifier']")))
#     username.clear()
#     username.send_keys(email)
#     time.sleep(2)
#     alert = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.XPATH,
#                                     '/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/span'))).click()
#     time.sleep(2)
#     password = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='password']")))
#     password.clear()
#     password.send_keys(passw)
#     time.sleep(2)
#     alert = WebDriverWait(driver, 10).until(
#         EC.element_to_be_clickable((By.XPATH,
#                                     '/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/span'))).click()
#     try:
#         altemail = WebDriverWait(driver, 10).until(
#             EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='knowledgePreregisteredEmailResponse']")))
#         altemail.clear()
#         altemail.send_keys(alt_email)
#         alert = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH,'/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[2]/div/div[1]/div/div/button/span'))).click()
#         login_meter = True
#     except:
#         print('No first-level of verification')
#         login_meter = True
#     if login_meter:
#         print('Login Successfull!')

def final_linkss(links):
    links_final = []
    for link in links:
        vid_id = link[31:]
        video_link = f'https://www.youtube.com/watch?v={vid_id}'
        links_final.append(video_link)
    print(f'{len(links_final)} filtered links')
    return links_final

