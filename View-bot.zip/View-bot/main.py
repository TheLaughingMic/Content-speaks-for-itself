# from pytube import YouTube
import pafy
import time
from selenium import webdriver
from script import link_grabber
from script import final_linkss

url = 'https://www.youtube.com/channel/UCOhklJGkpPXIb9vkvEwxw7A/videos'
driver = webdriver.Chrome('chromedriver.exe')
links = link_grabber(url, driver)
time.sleep(0.5)
final_links = final_linkss(links)
end_final_links = final_links[0:8]
time.sleep(0.5)


# Tracking
watchtime = 0
num_vid = 0
cycle = 0
# Playing video
for j in range(0, 3):
    for i in range(0, len(end_final_links)):
        video = final_links[i]
        ytvid = pafy.new(video)
        vid_length = ytvid.length
        driver.get(video)
        time.sleep(vid_length+1)
        watchtime += vid_length
        driver.delete_all_cookies()
        num_vid += 1
        print(f'{num_vid} videos watched!')
    cycle += 1
    print(f'{cycle} cycle(s) completed!')

watchtime = ((watchtime / 60) / 60)
print(f'Total Views given: {num_vid}')
print(f'Total watchtime given: {watchtime}hr')
driver.close()
