import requests

url = 'https://www.y2mate.com/'
r = requests.get(url=url)

print(r.request.body)