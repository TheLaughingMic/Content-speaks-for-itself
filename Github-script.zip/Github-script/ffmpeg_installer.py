# https://drive.google.com/file/d/188KmwOsWHNqcLAORLfvd5WbkA5VmQtDw/view?usp=sharing
import gdown
from shutil import unpack_archive

ffmpeg = '188KmwOsWHNqcLAORLfvd5WbkA5VmQtDw'
ffmpeg_output = 'D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\ffmpeg.zip'
gdown.download(id=ffmpeg, output=ffmpeg_output, quiet=False)
unpack_archive('D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\ffmpeg.zip', 'C:/')
