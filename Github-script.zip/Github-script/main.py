import pylivestream.api as pls
import time
import gdown

# def download_file_from_google_drive(id, destination):
#     def get_confirm_token(response):
#         for key, value in response.cookies.items():
#             if key.startswith('download_warning'):
#                 return value
#
#         return None
#
#     def save_response_content(response, destination):
#         CHUNK_SIZE = 32768
#
#         with open(destination, "wb") as f:
#             for chunk in response.iter_content(CHUNK_SIZE):
#                 if chunk: # filter out keep-alive new chunks
#                     f.write(chunk)
#
#     URL = "https://docs.google.com/uc?export=download"
#
#     session = requests.Session()
#
#     response = session.get(URL, params = { 'id' : id }, stream = True)
#     token = get_confirm_token(response)
#
#     if token:
#         params = { 'id' : id, 'confirm' : token }
#         response = session.get(URL, params = params, stream = True)
#
#     save_response_content(response, destination)
#
Video = '1tQHZXd-cuu4BT8iZD0FQy5zzJfKGk8zX'
ffmpeg = '1SioxZzXIma9hp550r58jJ936jJnsWeHA'
ffprobe = '1er-7Fj7j-v7d1BghZMcpH44g2Ma_roK0'
ffplay = '1rylBWTof8irSikQSxw9NCRohq3bKAyIq'
Video_output = "D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\final.mp4"
ffmpeg_output = 'D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\ffmpeg.exe'
ffprobe_output = 'D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\ffprobe.exe'
ffplay_output = 'D:\\a\Live_hu_ma_bhai\Live_hu_ma_bhai\Github-script\Github-script\\ffplay.exe'
print('Downloading files...')
gdown.download(id=Video, output=Video_output, quiet=False)
gdown.download(id=ffmpeg, output=ffmpeg_output, quiet=False)
gdown.download(id=ffplay, output=ffplay_output, quiet=False)
gdown.download(id=ffprobe, output=ffprobe_output, quiet=False)


delay = (5*60*60)+(30*60)
end_time = time.time() + delay

print(end_time)
while time.time() < end_time:
    pls.stream_file(
        ini_file='pylivestream.ini',
        websites='youtube',
        assume_yes=True,
        video_file='final.mp4'
    )